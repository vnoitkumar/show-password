# Show Password
A Google Chrome extension, Shows password when clicking the extension icon and hides when you click it again
